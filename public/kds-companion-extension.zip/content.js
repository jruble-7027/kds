// Chick-fil-A Kitchen KDS Companion Content Script for https://order-management.cfahome.com/*
// Extracts:
// 1. Primary Contact Name & Cell Number
// 2. Pickup / Delivery Time
// 3. Delivery Address (if Delivery) & Special Instructions / Paper Goods
// 4. Strictly Food Items + Quantities listed under "Item Name" -> "Subtotal" (ignoring Price & Event Summary headers)

(function () {
  'use strict';

  if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    return;
  }

  const oldRoot = document.getElementById('cfa-kds-companion-root');
  if (oldRoot) oldRoot.remove();

  let kdsOrders = [];
  let dashboardRowsData = [];
  let iframeRowsData = [];
  let scrapedPageItems = [];
  let lastAutoSyncedSignature = '';
  let isBulkCrawling = false;
  let isPanelOpen = true;

  const PROMISED_DATE_REGEX = /\b(?:(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?),?\s+)?(?:(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:,?\s*\d{4})?|\d{1,2}\/\d{1,2}\/\d{2,4}),?\s*(?:at\s+)?\d{1,2}:\d{2}\s*[ap]m\b/i;
  const PROMISED_DATE_GLOBAL_REGEX = /\b(?:(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?),?\s+)?(?:(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:,?\s*\d{4})?|\d{1,2}\/\d{1,2}\/\d{2,4}),?\s*(?:at\s+)?\d{1,2}:\d{2}\s*[ap]m\b/gi;

  const DEFAULT_CLOUD_URL = 'https://kds-production-9203.up.railway.app';
  let kdsServerUrl = (localStorage.getItem('cfa_kds_server_url') || DEFAULT_CLOUD_URL).trim().replace(/\/+$/, '');
  let kdsApiKey = (localStorage.getItem('cfa_kds_api_key') || '').trim();

  // Dual-Transport KDS API Caller (Supports Railway Cloud URL + Password/Key OR Localhost)
  async function callKdsApi(message) {
    const msgWithCfg = {
      ...message,
      serverUrl: kdsServerUrl,
      apiKey: kdsApiKey
    };

    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
        const bgRes = await new Promise((resolve) => {
          chrome.runtime.sendMessage(msgWithCfg, (res) => {
            if (chrome.runtime.lastError) {
              resolve(null);
            } else {
              resolve(res);
            }
          });
        });
        if (bgRes && bgRes.ok) return bgRes;
      }
    } catch (e) {}

    const urls = kdsServerUrl
      ? [kdsServerUrl, DEFAULT_CLOUD_URL, 'http://localhost:3000', 'http://127.0.0.1:3000']
      : [DEFAULT_CLOUD_URL, 'http://localhost:3000', 'http://127.0.0.1:3000'];
    const authHeaders = kdsApiKey ? { 'X-KDS-Key': kdsApiKey } : {};

    for (const base of urls) {
      try {
        if (message.type === 'KDS_GET_ORDERS') {
          const r = await fetch(`${base}/api/orders`, { headers: authHeaders });
          const orders = await r.json();
          if (r.ok) return { ok: true, orders, baseUrl: base };
        } else if (message.type === 'KDS_SYNC_ORDER') {
          const r = await fetch(`${base}/api/orders/sync`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...authHeaders },
            body: JSON.stringify(message.payload)
          });
          const data = await r.json();
          if (r.ok) return { ok: true, data };
        } else if (message.type === 'KDS_QUICK_ADD') {
          const r = await fetch(`${base}/api/orders/${encodeURIComponent(message.orderId)}/quick-add`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...authHeaders },
            body: JSON.stringify(message.payload)
          });
          const data = await r.json();
          if (r.ok) return { ok: true, data };
        }
      } catch (err) {}
    }

    return {
      ok: false,
      error: 'Could not reach Kitchen KDS Server. Check Server URL / Password in ⚙️ Settings.'
    };
  }

  // Parses dates like:
  // "Friday, November 6, 6:30 am", "Saturday, 11/07/26, 7:00 AM", "Thu, Nov 19, 6:15 pm", "Nov 19 6:15 pm", "11/19/2026 1:00 pm"
  // Returns null if dateStr is empty or unparseable so existing KDS dates are never overwritten with Today!
  function parsePromisedDateToIso(dateStr) {
    if (!dateStr) return null;
    try {
      const currentYear = new Date().getFullYear();
      const cleaned = dateStr
        .replace(/^(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?),?\s*/i, '')
        .replace(/\bat\s+/i, '')
        .trim();

      // Format 1: "11/07/26, 7:00 AM" or "11/19/2026 6:15 pm"
      const slashMatch = cleaned.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4}),?\s*(\d{1,2}:\d{2}\s*[ap]m)$/i);
      if (slashMatch) {
        const month = Number(slashMatch[1]);
        const day = Number(slashMatch[2]);
        let year = Number(slashMatch[3]);
        if (year < 100) year += 2000;
        const parsed = new Date(`${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')} ${slashMatch[4]}`);
        if (!isNaN(parsed.getTime())) return parsed.toISOString();
      }

      // Format 2: "November 6, 6:30 am" or "Nov 19, 6:15 pm" or "Nov 19 6:15 pm"
      const wordMatch = cleaned.match(/^([A-Za-z]+\s+\d{1,2})(?:,?\s*(\d{4}))?,?\s*(\d{1,2}:\d{2}\s*[ap]m)$/i);
      if (wordMatch) {
        const year = wordMatch[2] || currentYear;
        const parsed = new Date(`${wordMatch[1]}, ${year} ${wordMatch[3]}`);
        if (!isNaN(parsed.getTime())) return parsed.toISOString();
      }

      const fallback = new Date(dateStr);
      if (!isNaN(fallback.getTime())) {
        if (fallback.getFullYear() < 2020) {
          fallback.setFullYear(currentYear);
        }
        return fallback.toISOString();
      }
    } catch (e) {}
    return null;
  }

  function buildOrderCode(guestName, promisedDateStr) {
    const initials = (guestName || 'CFA')
      .split(/\s+/)
      .map((w) => w[0] || '')
      .join('')
      .toUpperCase()
      .slice(0, 3);
    const timeMatch = (promisedDateStr || '').match(/(\d{1,2}):(\d{2})\s*([ap]m)/i);
    if (timeMatch) {
      return `#CFA-${initials}-${timeMatch[1]}${timeMatch[2]}${timeMatch[3][0].toUpperCase()}`;
    }
    return `#CFA-${initials}`;
  }

  function isBadPaymentStatus(statusStr) {
    return /\b(error|cancell?ed|failed|declined|void)\b/i.test(statusStr || '');
  }

  function isPastOrderTime(isoStr) {
    if (!isoStr) return false;
    const t = new Date(isoStr).getTime();
    if (isNaN(t)) return false;
    // 12-hour buffer so timezone discrepancies between tablet and UTC server do not drop upcoming orders
    return t < (Date.now() - 12 * 3600 * 1000);
  }

  function cleanGuestName(raw) {
    if (!raw) return '';
    return raw
      .replace(
        /\b(Guest\s*Name|Promised\s*Date|Method|Total|Payment\s*Status|Source|Upcoming|Past|Orders|Search\s*guest\s*name|Select\s*Date\s*Range|Payment|Received|Pending|Error|Failed|Declined|Cancell?ed|Voided|Catering|Management|Tool|Mobile|App|Web|Pickup|Delivery|Curbside|Paid|Unpaid|Invoiced)\b/gi,
        ''
      )
      .replace(/\$[\d,.]+/g, '')
      .replace(/^[^A-Za-z]+/g, '')
      .replace(/\b[V]\b\s*/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function parseRowBlockText(blockText) {
    const normalized = blockText.replace(/\r/g, '\n').replace(/\t/g, '\n');
    const dateMatch = normalized.match(PROMISED_DATE_REGEX);
    if (!dateMatch) return null;

    const promisedDate = dateMatch[0].replace(/\s+/g, ' ').trim();
    const dateIdx = normalized.indexOf(dateMatch[0]);

    const beforeDate = normalized.slice(0, dateIdx);
    const afterDate = normalized.slice(dateIdx + dateMatch[0].length);

    const beforeLines = beforeDate
      .split('\n')
      .map((l) => cleanGuestName(l))
      .filter((l) => l.length >= 2 && /[A-Za-z]{2,}/.test(l));

    let guestName = '';
    if (
      beforeLines.length >= 2 &&
      !beforeLines[beforeLines.length - 2].includes(' ') &&
      !beforeLines[beforeLines.length - 1].includes(' ')
    ) {
      guestName = `${beforeLines[beforeLines.length - 2]} ${beforeLines[beforeLines.length - 1]}`;
    } else if (beforeLines.length > 0) {
      guestName = beforeLines[beforeLines.length - 1];
    }
    guestName = cleanGuestName(guestName);
    if (!guestName || guestName.length < 2) return null;

    const methodMatch = afterDate.match(/\b(Pickup|Delivery|Curbside|Dine-In)\b/i);
    const totalMatch = afterDate.match(/\$\d[\d,]*\.\d{2}/);
    const paymentMatch = afterDate.match(
      /\b(Payment\s+Received|Payment\s+Pending|Payment\s+Error|Payment\s+Failed|Order\s+Cancell?ed|Cancell?ed|Error|Failed|Declined|Paid|Unpaid|Invoiced|House\s+Account)\b/i
    );
    const sourceMatch = afterDate.match(/\b(Catering\s+Management\s+Tool|Mobile\s+App|Web|One\s+App|Phone|POS)\b/i);

    const method = methodMatch ? (/delivery/i.test(methodMatch[1]) ? 'Delivery' : 'Pickup') : 'Pickup';
    const total = totalMatch ? totalMatch[0] : '';
    const paymentStatus = paymentMatch ? paymentMatch[0].replace(/\s+/g, ' ').trim() : 'Payment Received';
    const source = sourceMatch ? sourceMatch[0].replace(/\s+/g, ' ') : 'CFA Home';

    return {
      guestName,
      promisedDate,
      pickupIso: parsePromisedDateToIso(promisedDate),
      method,
      total,
      paymentStatus,
      source,
      orderNumber: buildOrderCode(guestName, promisedDate)
    };
  }

  // Precision Parser for the Open Order Modal on order-management.cfahome.com:
  // 1. Reads Event Summary header fields: Pickup/Delivery Time, Primary Contact Name & Cell #, Delivery Address (if Delivery), Special Instructions
  // 2. Reads Food Items + Quantities strictly between "Item Name" ("Quantity" / "Price") and "Subtotal" (ignoring Price!)
  function parseOpenOrderSummary(rawPageText) {
    const text = (rawPageText || (document.body ? document.body.innerText : ''))
      .replace(root ? root.innerText || '' : '');

    if (!/Item\s+Name/i.test(text) || !/Subtotal/i.test(text)) {
      return null;
    }

    const itemNameHeaderIdx = text.search(/Item\s+Name/i);
    const subtotalIdx = text.search(/Subtotal/i);
    if (itemNameHeaderIdx === -1 || subtotalIdx === -1 || subtotalIdx <= itemNameHeaderIdx) {
      return null;
    }

    // --- PART 1: Parse Header Metadata (Before "Order Summary" / "Item Name") ---
    const headerSection = text.slice(Math.max(0, itemNameHeaderIdx - 1200), itemNameHeaderIdx);

    let guestName = '';
    let contactPhone = '';
    let pickupTimeStr = '';
    let orderType = 'Pickup';
    let deliveryAddress = '';
    let specialInstructions = '';
    let paperGoodsNote = '';

    // A) Extract Pickup Time or Delivery Time (e.g. "Saturday, 11/07/26, 7:00 AM" or "Friday, December 11, 8:30 pm")
    const timeMatch = headerSection.match(
      /\b(Pickup|Delivery|Promised|Event)\s+(?:Date\s*(?:&|and)?\s*)?(?:Time|Date)\s*[\r\n:]+\s*([^\r\n]+)/i
    );
    if (timeMatch) {
      if (/delivery/i.test(timeMatch[1])) orderType = 'Delivery';
      pickupTimeStr = timeMatch[2].trim();
    } else {
      const anyHeaderDateMatch = headerSection.match(PROMISED_DATE_REGEX);
      if (anyHeaderDateMatch) {
        pickupTimeStr = anyHeaderDateMatch[0].replace(/\s+/g, ' ').trim();
      }
    }

    // B) Extract Primary Contact Name & Cell Number (strictly between "Primary Contact" and "Pickup Restaurant" / "Delivery Address" / "Guest Count")
    const contactBlockMatch = headerSection.match(
      /Primary\s+Contact\s*[\r\n:]+([\s\S]+?)(?=Pickup\s+Restaurant|Delivery\s+Address|Delivery\s+Location|Guest\s+Count|Order\s+Summary|$)/i
    );
    if (contactBlockMatch) {
      const contactBlock = contactBlockMatch[1];
      const contactLines = contactBlock
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean);

      if (contactLines.length > 0) {
        guestName = contactLines[0];
      }

      const phoneMatch = contactBlock.match(/\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}/);
      if (phoneMatch) {
        contactPhone = phoneMatch[0].trim();
      }
    }

    // Fallback for Guest Name from modal title right above "Payment Received" / "Error" / "Cancelled" (for POS / CMT orders without "Primary Contact" block)
    let modalPaymentStatus = '';
    const modalPayMatch = headerSection.match(
      /\b(Payment\s+Received|Payment\s+Pending|Payment\s+Error|Payment\s+Failed|Order\s+Cancell?ed|Cancell?ed|Error)\b/i
    );
    if (modalPayMatch) {
      modalPaymentStatus = modalPayMatch[0].replace(/\s+/g, ' ').trim();
    }

    if (!guestName) {
      const headerLines = headerSection
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean);
      for (let i = 0; i < headerLines.length; i++) {
        if (/^(?:✓\s*|×\s*|✕\s*|⚠️\s*)?(?:Payment\s+(?:Received|Pending|Status|Error|Failed)|Order\s+Cancell?ed|Cancell?ed|Error)$/i.test(headerLines[i]) && i > 0) {
          const candidate = headerLines[i - 1].replace(/^[✓×✕\s]+/, '').trim();
          if (candidate.length >= 2 && candidate.length <= 45 && !/Source|Total|Method|Event\s+Summary/i.test(candidate)) {
            guestName = candidate;
          }
        }
      }
    }

    // C) Extract Delivery Address ONLY if this is a Delivery (ignore "Pickup Restaurant: Peace Haven...")
    const deliveryMatch = headerSection.match(
      /Delivery\s+(?:Address|Location)\s*[\r\n:]+([\s\S]+?)(?=Guest\s+Count|Catering\s+Occasion|Special\s+Instructions|Paper\s+Goods|Order\s+Summary|$)/i
    );
    if (deliveryMatch) {
      orderType = 'Delivery';
      deliveryAddress = deliveryMatch[1]
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l && !/^None$/i.test(l))
        .join(', ');
    }

    // D) Extract Special Instructions (ignore "None" and stop before Secondary Contact / Paper Goods)
    const specialMatch = headerSection.match(
      /Special\s+Instructions\s*[\r\n:]+([\s\S]+?)(?=Secondary\s+Contact|Paper\s+Goods|Order\s+Summary|$)/i
    );
    if (specialMatch) {
      const cleanedSpecial = specialMatch[1]
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l && !/^None$/i.test(l))
        .join(' ');
      if (cleanedSpecial) {
        specialInstructions = cleanedSpecial;
      }
    }

    // E) Extract Paper Goods request (or standalone note above Order Summary like Phil Ziesemer's "Please include plates, cutlery, napkins and cups.")
    const paperMatch = headerSection.match(
      /Paper\s+Goods\s*[\r\n:]+([\s\S]+?)(?=Secondary\s+Contact|Order\s+Summary|$)/i
    );
    if (paperMatch) {
      const cleanedPaper = paperMatch[1]
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l && !/^None$/i.test(l))
        .join(' ');
      if (cleanedPaper) {
        paperGoodsNote = cleanedPaper;
      }
    } else if (!/Event\s+Summary/i.test(headerSection)) {
      // For simple modals (like Phil Ziesemer's screenshot) that only have "Please include plates, cutlery, napkins and cups." above Order Summary
      const simpleNoteMatch = headerSection.match(/(Please\s+(?:include|do\s+not\s+include)[^\r\n]+)/i);
      if (simpleNoteMatch) {
        paperGoodsNote = simpleNoteMatch[1].trim();
      }
    }

    // Combine Special Instructions & Paper Goods cleanly for the Kitchen Note banner
    const notesArray = [];
    if (specialInstructions) notesArray.push(specialInstructions);
    if (paperGoodsNote) notesArray.push(paperGoodsNote);
    const combinedSpecialNotes = notesArray.join(' • ');

    // --- PART 2: Parse Food Items & Quantities strictly between "Item Name" ("Price") and "Subtotal" ---
    let itemsSection = text.slice(itemNameHeaderIdx, subtotalIdx);
    // Strip the table column headers: "Item Name", "Quantity", "Price"
    itemsSection = itemsSection
      .replace(/^Item\s+Name[\s\r\n]+Quantity[\s\r\n]+Price/i, '')
      .replace(/\b(Item\s+Name|Quantity|Price)\b/gi, '')
      .trim();

    const items = [];
    // Every item in Order Summary has: <Item Name> <Quantity> <Price ($xx.xx or Free)>
    // Matching both "$xx.xx" and "Free" as the end-of-item delimiter separates sauces, modifiers, and trays cleanly, and discards the price!
    const itemRegex = /([\s\S]+?)\s+(\d{1,4})\s+(?:\$\d[\d,]*\.\d{2}|\bFree\b)/gi;
    let match;
    while ((match = itemRegex.exec(itemsSection)) !== null) {
      const rawName = match[1]
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean)
        .join(' ');
      const qty = Number(match[2]) || 1;

      if (rawName && rawName.length >= 2) {
        // Categorize Sauces/Dressings vs Food & Menu
        const isSauceOrPaper = /(Sauce|Dressing|Jam|Honey|Syrup|Ketchup|Mayo|Mustard|Pickles|Utensil|Plate|Napkin|Ice)/i.test(rawName) && !/(Tray|Sandwich|Biscuit|Meal|Wrap|Nugget|Strip|Minis)/i.test(rawName);
        items.push({
          name: rawName,
          quantity: qty,
          category: isSauceOrPaper ? 'Sauces & Condiments' : 'Food & Menu',
          unit: 'count'
        });
      }
    }

    return {
      guestName,
      contactPhone,
      pickupTimeStr,
      orderType,
      deliveryAddress,
      paymentStatus: modalPaymentStatus,
      specialNotes: combinedSpecialNotes,
      items
    };
  }

  // Root UI Container
  const root = document.createElement('div');
  root.id = 'cfa-kds-companion-root';
  root.innerHTML = `
    <div id="cfa-kds-panel" class="cfa-kds-panel">
      <div class="cfa-kds-header">
        <div class="cfa-kds-header-title">
          <strong>🐔 CFA Kitchen KDS Companion</strong>
          <span id="cfa-kds-conn-text">Connecting to Kitchen Touchscreen...</span>
        </div>
        <div style="display:flex; gap:6px; align-items:center;">
          <button id="cfa-kds-settings-toggle" class="cfa-kds-close-btn" title="Cloud / Server URL Settings" style="font-size:14px;">⚙️</button>
          <button id="cfa-kds-minimize" class="cfa-kds-close-btn" title="Minimize">−</button>
        </div>
      </div>

      <div class="cfa-kds-body">
        <div id="cfa-kds-toast" class="cfa-kds-toast"></div>

        <!-- Collapsible Cloud / Railway Server Settings -->
        <div id="cfa-kds-settings-box" class="cfa-kds-section" style="display:none; background:#F8FAFC; border-color:#CBD5E1;">
          <div class="cfa-kds-section-title" style="margin-bottom:6px;">
            <span>🌐 KDS Server URL (Local or Railway Cloud)</span>
          </div>
          <input id="cfa-kds-server-url" class="cfa-kds-input" placeholder="http://localhost:3000 or https://...up.railway.app" style="margin-bottom:6px; width:100%;" />
          <input id="cfa-kds-api-key" type="password" class="cfa-kds-input" placeholder="Team Password / KDS_PASSWORD (if set)" style="margin-bottom:6px; width:100%;" />
          <button id="cfa-kds-save-settings" class="cfa-kds-secondary-btn" style="width:100%; padding:6px;">✓ Save & Reconnect</button>
        </div>

        <!-- Bulk Dashboard Sync Banner -->
        <div id="cfa-kds-bulk-box" class="cfa-kds-section" style="background: #EFF6FF; border-color: #BFDBFE;">
          <div class="cfa-kds-section-title" style="color: #1E40AF; margin-bottom: 6px;">
            <span>📋 CFA Dashboard Orders Found: <strong id="cfa-kds-upcoming-count">0</strong></span>
            <button id="cfa-kds-scan-btn" class="cfa-kds-secondary-btn">🔄 Re-Scan</button>
          </div>
          <button id="cfa-kds-sync-all-btn" class="cfa-kds-sync-all-btn">
            📥 Sync All Orders + Food Details to Kitchen KDS
          </button>

          <!-- Game Day Auto-Refresh & Upload Control -->
          <div style="margin-top: 8px; padding-top: 8px; border-top: 1px dashed #BFDBFE; display: flex; align-items: center; justify-content: space-between; gap: 6px; flex-wrap: wrap;">
            <select id="cfa-kds-autosync-interval" class="cfa-kds-select" style="flex: 1; min-width: 155px; font-size: 11.5px; padding: 4px 6px; font-weight: 600;">
              <option value="0">⏸️ Auto-Refresh: Off</option>
              <option value="15">⏱️ Auto-Refresh: Every 15m (Game Day)</option>
              <option value="10">⏱️ Auto-Refresh: Every 10m</option>
              <option value="5">⏱️ Auto-Refresh: Every 5m</option>
            </select>
            <span id="cfa-kds-autosync-status" style="font-size: 11px; color: #1E40AF; font-weight: 700; white-space: nowrap;">Off</span>
          </div>
        </div>

        <!-- Section 1: Selected Guest Order -->
        <div class="cfa-kds-section">
          <div class="cfa-kds-section-title">
            <span>1. Primary Contact & Pickup Info</span>
            <span id="cfa-kds-promised-badge" style="font-size: 10.5px; color: #E5173F; font-weight: 700;"></span>
          </div>

          <div style="margin-bottom: 8px;">
            <select id="cfa-kds-existing-select" class="cfa-kds-select">
              <option value="__new__">Select a Guest from Dashboard or KDS...</option>
            </select>
          </div>

          <div class="cfa-kds-field-row">
            <input id="cfa-kds-customer" class="cfa-kds-input" placeholder="Primary Contact Name" />
            <input id="cfa-kds-phone" class="cfa-kds-input" placeholder="Cell # (e.g. 336-345-1221)" />
          </div>

          <div class="cfa-kds-field-row" style="margin-bottom: 0;">
            <input id="cfa-kds-promised" class="cfa-kds-input" placeholder="Pickup / Delivery Time" />
            <select id="cfa-kds-type" class="cfa-kds-select">
              <option value="Pickup">Pickup</option>
              <option value="Delivery">Delivery</option>
            </select>
          </div>
          <input id="cfa-kds-order-num" type="hidden" />
        </div>

        <!-- Detected Order Summary Food Items (Auto-populated when an order is opened!) -->
        <div id="cfa-kds-detected-items-box" class="cfa-kds-section" style="background: #ECFDF5; border-color: #A7F3D0; display: none;">
          <div class="cfa-kds-section-title" style="color: #047857; margin-bottom: 4px;">
            <span>🍗 Item Name & Quantity (<span id="cfa-kds-detected-count">0</span>)</span>
            <span style="font-size: 10px; color: #059669;">✓ Synced to KDS</span>
          </div>
          <div id="cfa-kds-detected-list" style="font-size: 12px; color: #065F46; max-height: 100px; overflow-y: auto;"></div>
        </div>

        <!-- Section 2: 1-Click Phone Call / Sauce Additions (Flashes Kitchen Red) -->
        <div class="cfa-kds-section">
          <div class="cfa-kds-section-title">
            <span>2. Instant Add & Flash Kitchen Red 🚨</span>
          </div>
          <div class="cfa-kds-presets">
            <button class="cfa-kds-preset-btn" data-name="Barbeque Sauce Packets" data-qty="50" data-cat="Sauces" data-unit="Packets">⚡ +50 BBQ Sauces</button>
            <button class="cfa-kds-preset-btn" data-name="Chick-fil-A® Sauce Packets" data-qty="50" data-cat="Sauces" data-unit="Packets">⚡ +50 CFA Sauces</button>
            <button class="cfa-kds-preset-btn" data-name="Polynesian Sauce Packets" data-qty="25" data-cat="Sauces" data-unit="Packets">⚡ +25 Polynesian</button>
            <button class="cfa-kds-preset-btn" data-name="Garden Herb Ranch Packets" data-qty="25" data-cat="Sauces" data-unit="Packets">⚡ +25 Ranch</button>
            <button class="cfa-kds-preset-btn" data-name="Sweet Tea Gallon" data-qty="2" data-cat="Beverages" data-unit="Gallons">⚡ +2 Gal Sweet Tea</button>
            <button class="cfa-kds-preset-btn" data-name="Serving Utensils & Plates Kit" data-qty="25" data-cat="Paper Goods" data-unit="Sets">⚡ +25 Plates/Utensils</button>
          </div>
        </div>

        <!-- Section 3: Custom Item or Urgent Kitchen Alert Note -->
        <div class="cfa-kds-section">
          <div class="cfa-kds-section-title">
            <span>3. Custom Addition / Kitchen Flash Note</span>
          </div>
          <div class="cfa-kds-field-row">
            <input id="cfa-kds-custom-item" class="cfa-kds-input" placeholder="Item (e.g. Cookie Tray)" />
            <input id="cfa-kds-custom-qty" type="number" min="1" value="1" class="cfa-kds-input" placeholder="Qty" />
          </div>
          <textarea id="cfa-kds-note" class="cfa-kds-textarea" placeholder="Urgent kitchen note (e.g. Guest called to add 50 BBQ sauces)..."></textarea>
          <button id="cfa-kds-send-btn" class="cfa-kds-primary-btn" style="margin-top: 8px;">
            🚨 Send to Kitchen KDS (Flash Red)
          </button>
        </div>
      </div>
    </div>

    <button id="cfa-kds-fab" class="cfa-kds-fab" title="Open Kitchen KDS Companion">
      <span id="cfa-kds-dot" class="cfa-kds-status-dot"></span>
      <span>🍳 Kitchen KDS Sync</span>
    </button>
  `;

  document.body.appendChild(root);

  const panel = document.getElementById('cfa-kds-panel');
  const fab = document.getElementById('cfa-kds-fab');
  const minimizeBtn = document.getElementById('cfa-kds-minimize');
  const scanBtn = document.getElementById('cfa-kds-scan-btn');
  const syncAllBtn = document.getElementById('cfa-kds-sync-all-btn');
  const upcomingCountEl = document.getElementById('cfa-kds-upcoming-count');
  const existingSelect = document.getElementById('cfa-kds-existing-select');
  const orderNumInput = document.getElementById('cfa-kds-order-num');
  const customerInput = document.getElementById('cfa-kds-customer');
  const phoneInput = document.getElementById('cfa-kds-phone');
  const promisedInput = document.getElementById('cfa-kds-promised');
  const promisedBadge = document.getElementById('cfa-kds-promised-badge');
  const typeSelect = document.getElementById('cfa-kds-type');
  const customItemInput = document.getElementById('cfa-kds-custom-item');
  const customQtyInput = document.getElementById('cfa-kds-custom-qty');
  const noteInput = document.getElementById('cfa-kds-note');
  const sendBtn = document.getElementById('cfa-kds-send-btn');
  const toast = document.getElementById('cfa-kds-toast');
  const connText = document.getElementById('cfa-kds-conn-text');
  const statusDot = document.getElementById('cfa-kds-dot');
  const detectedBox = document.getElementById('cfa-kds-detected-items-box');
  const detectedCount = document.getElementById('cfa-kds-detected-count');
  const detectedList = document.getElementById('cfa-kds-detected-list');

  function showToast(msg, type = 'success') {
    toast.textContent = msg;
    toast.className = `cfa-kds-toast ${type}`;
    setTimeout(() => {
      toast.className = 'cfa-kds-toast';
    }, 6500);
  }

  minimizeBtn.addEventListener('click', () => {
    isPanelOpen = false;
    panel.classList.add('hidden');
  });

  const settingsToggleBtn = document.getElementById('cfa-kds-settings-toggle');
  const settingsBox = document.getElementById('cfa-kds-settings-box');
  const serverUrlInput = document.getElementById('cfa-kds-server-url');
  const apiKeyInput = document.getElementById('cfa-kds-api-key');
  const saveSettingsBtn = document.getElementById('cfa-kds-save-settings');

  serverUrlInput.value = kdsServerUrl;
  apiKeyInput.value = kdsApiKey;

  settingsToggleBtn.addEventListener('click', () => {
    settingsBox.style.display = settingsBox.style.display === 'none' ? 'block' : 'none';
  });

  saveSettingsBtn.addEventListener('click', async () => {
    kdsServerUrl = serverUrlInput.value.trim().replace(/\/+$/, '');
    kdsApiKey = apiKeyInput.value.trim();
    localStorage.setItem('cfa_kds_server_url', kdsServerUrl);
    localStorage.setItem('cfa_kds_api_key', kdsApiKey);
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
        chrome.runtime.sendMessage({
          type: 'KDS_SAVE_CONFIG',
          serverUrl: kdsServerUrl,
          apiKey: kdsApiKey
        });
      }
    } catch (e) {}
    settingsBox.style.display = 'none';
    showToast(`✓ Saved KDS Server: ${kdsServerUrl || 'http://localhost:3000'}`, 'success');
    await refreshKdsOrders();
  });

  fab.addEventListener('click', () => {
    isPanelOpen = !isPanelOpen;
    panel.classList.toggle('hidden', !isPanelOpen);
    if (isPanelOpen) {
      refreshKdsOrders();
      scanCfaDashboardAndTabs();
    }
  });

  function selectGuestOrder(rowObj, rowElement = null) {
    document.querySelectorAll('.cfa-kds-row-selected').forEach((el) => {
      el.classList.remove('cfa-kds-row-selected');
    });
    if (rowElement) {
      rowElement.classList.add('cfa-kds-row-selected');
    }

    customerInput.value = rowObj.guestName || '';
    orderNumInput.value = rowObj.orderNumber || buildOrderCode(rowObj.guestName, rowObj.promisedDate);
    promisedInput.value = rowObj.promisedDate || '';
    promisedBadge.textContent = rowObj.orderNumber || '';
    typeSelect.value = /delivery/i.test(rowObj.method) ? 'Delivery' : 'Pickup';

    const existingKds = kdsOrders.find(
      (o) =>
        o.customer_name.toLowerCase() === (rowObj.guestName || '').toLowerCase() ||
        o.order_number.toLowerCase() === (orderNumInput.value || '').toLowerCase()
    );
    if (existingKds) {
      existingSelect.value = existingKds.id;
      orderNumInput.value = existingKds.order_number;
      if (existingKds.customer_phone) phoneInput.value = existingKds.customer_phone;
    }

    if (!isPanelOpen) {
      isPanelOpen = true;
      panel.classList.remove('hidden');
    }
  }

  // Dismiss any open CFA Home modal/overlay so it doesn't block background table row clicks
  function closeOpenCfaModal() {
    try {
      // 1. Dispatch Escape key to cancel/close any active dialog
      const escOptions = { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true };
      document.dispatchEvent(new KeyboardEvent('keydown', escOptions));
      document.dispatchEvent(new KeyboardEvent('keyup', escOptions));
      window.dispatchEvent(new KeyboardEvent('keydown', escOptions));

      // 2. Click any explicit close or dismiss buttons in modal dialogs (excluding extension elements)
      const closeBtns = Array.from(document.querySelectorAll(
        'button[aria-label*="close" i], button[title*="close" i], button.close, [class*="modal" i] button[class*="close" i], [role="dialog"] button[aria-label*="close" i], [role="dialog"] button:has(svg), .cdk-overlay-pane button[aria-label*="close" i]'
      ));
      for (const b of closeBtns) {
        if (root.contains(b)) continue;
        b.click();
      }

      // 3. Click backdrop if present
      const backdrops = Array.from(document.querySelectorAll('.modal-backdrop, .cdk-overlay-backdrop, [class*="backdrop" i]'));
      for (const bd of backdrops) {
        if (root.contains(bd)) continue;
        bd.click();
      }
    } catch (e) {}
  }

  function findClickableElementForGuest(guestName) {
    if (!guestName || !document.body) return null;
    const lowerTarget = guestName.toLowerCase();
    const parts = lowerTarget.split(/\s+/).filter(Boolean);

    const candidates = Array.from(document.body.querySelectorAll('tr, [role="row"], td, [role="cell"], a, span, div'));
    for (const el of candidates) {
      if (root.contains(el)) continue;
      const t = (el.innerText || '').replace(/\s+/g, ' ').trim().toLowerCase();
      if (t === lowerTarget || (parts.length >= 2 && t.includes(parts[0]) && t.includes(parts[1]) && t.length < 40)) {
        return el;
      }
    }
    return null;
  }

  // Target a specific row matching BOTH guest name AND promised pickup time (vital when a guest has multiple orders!)
  function findClickableElementForGuestAndTime(guestName, promisedTime) {
    if (!guestName || !document.body) return null;
    const lowerGuest = guestName.toLowerCase();
    const guestParts = lowerGuest.split(/\s+/).filter(Boolean);

    let timeSub = '';
    if (promisedTime) {
      const tm = promisedTime.match(/\b\d{1,2}:\d{2}\s*[ap]m\b/i);
      if (tm) timeSub = tm[0].toLowerCase().replace(/\s+/g, '');
    }

    // First pass: look for rows/containers containing BOTH guest and time
    const rows = Array.from(document.body.querySelectorAll('tr, [role="row"], li, [class*="row" i]'));
    for (const el of rows) {
      if (root.contains(el)) continue;
      const t = (el.innerText || '').replace(/\s+/g, ' ').trim().toLowerCase();
      const guestMatch = t.includes(lowerGuest) || (guestParts.length >= 2 && t.includes(guestParts[0]) && t.includes(guestParts[1]));
      const timeMatch = !timeSub || t.replace(/\s+/g, '').includes(timeSub);
      if (guestMatch && timeMatch) {
        const clickable = el.querySelector('a, button:not(.cfa-kds-row-btn), [role="button"], td:first-child');
        return clickable || el;
      }
    }

    // Second pass: any candidate element containing both
    const candidates = Array.from(document.body.querySelectorAll('tr, [role="row"], td, [role="cell"], a, span, div'));
    for (const el of candidates) {
      if (root.contains(el)) continue;
      const t = (el.innerText || '').replace(/\s+/g, ' ').trim().toLowerCase();
      const guestMatch = t.includes(lowerGuest) || (guestParts.length >= 2 && t.includes(guestParts[0]) && t.includes(guestParts[1]));
      const timeMatch = !timeSub || t.replace(/\s+/g, '').includes(timeSub);
      if (guestMatch && timeMatch) {
        return el;
      }
    }

    return findClickableElementForGuest(guestName);
  }

  // Safely get clickable element for a specific row object
  function findClickableElementForRow(row) {
    if (row && row.domElement && document.body.contains(row.domElement)) {
      const clickable = row.domElement.querySelector('a, button:not(.cfa-kds-row-btn), [role="button"], td:first-child');
      return clickable || row.domElement;
    }
    if (row && row.guestName) {
      return findClickableElementForGuestAndTime(row.guestName, row.promisedDate);
    }
    return null;
  }

  // Tablet & Mobile friendly tap / click dispatcher
  function triggerElementTap(el) {
    if (!el) return;
    try {
      if (typeof el.scrollIntoView === 'function') {
        el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      }
      el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true }));
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
      el.click();
    } catch (e) {
      try { el.click(); } catch (err) {}
    }
  }

  function scanCfaDashboardAndTabs() {
    const parsedRows = [];
    const seenKeys = new Set();

    // Strategy A: DOM elements containing 1 Promised Date
    const allElements = Array.from(document.body.querySelectorAll('tr, [role="row"], li, div'));
    for (const el of allElements) {
      if (root.contains(el)) continue;
      const text = el.innerText || '';
      if (text.length < 15 || text.length > 450) continue;
      if (/Event\s+Summary|Transaction\s+ID/i.test(text)) continue;

      const dateMatches = text.match(PROMISED_DATE_GLOBAL_REGEX);
      if (!dateMatches || dateMatches.length !== 1) continue;
      if (!/\$\d|\b(Pickup|Delivery)\b/i.test(text)) continue;

      const parsed = parseRowBlockText(text);
      if (!parsed || isPastOrderTime(parsed.pickupIso)) continue;

      const uniqueKey = `${parsed.guestName.toLowerCase()}|${parsed.promisedDate.toLowerCase()}`;
      if (seenKeys.has(uniqueKey)) continue;
      seenKeys.add(uniqueKey);
      parsed.domElement = el;
      parsedRows.push(parsed);

      if (el.tagName === 'TR' && !el.querySelector('.cfa-kds-row-action-cell')) {
        const actionCell = document.createElement('td');
        actionCell.className = 'cfa-kds-row-action-cell';
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'cfa-kds-row-btn';
        btn.innerHTML = '⚡ Kitchen KDS';
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          e.preventDefault();
          selectGuestOrder(parsed, el);
          showToast(`Selected ${parsed.guestName} (${parsed.promisedDate}) — Tap a preset to flash Kitchen!`);
        });
        actionCell.appendChild(btn);
        el.appendChild(actionCell);
      }
    }

    // Strategy B: Full-Page Text Scanner around Dashboard Promised Dates
    if (document.body) {
      let tableOnlyText = (document.body.innerText || '').replace(root.innerText || '', '');
      // Strip open modal section elements rather than slicing the whole page at first occurrence
      const openModals = Array.from(document.querySelectorAll('[role="dialog"], .modal, [class*="modal" i], [class*="dialog" i]'));
      for (const m of openModals) {
        if (m && m.innerText) {
          tableOnlyText = tableOnlyText.replace(m.innerText, '');
        }
      }

      const matches = Array.from(tableOnlyText.matchAll(PROMISED_DATE_GLOBAL_REGEX));
      for (let i = 0; i < matches.length; i++) {
        const match = matches[i];
        const dateIndex = match.index;
        const prevEnd = i > 0 ? matches[i - 1].index + matches[i - 1][0].length : Math.max(0, dateIndex - 200);
        const nextStart = i + 1 < matches.length ? matches[i + 1].index : Math.min(tableOnlyText.length, dateIndex + 250);

        const beforeChunk = tableOnlyText.slice(Math.max(prevEnd, dateIndex - 140), dateIndex);
        const afterChunk = tableOnlyText.slice(dateIndex, Math.min(nextStart, dateIndex + 180));
        const combinedChunk = beforeChunk + afterChunk;

        const parsed = parseRowBlockText(combinedChunk);
        if (parsed && !isPastOrderTime(parsed.pickupIso)) {
          const uniqueKey = `${parsed.guestName.toLowerCase()}|${parsed.promisedDate.toLowerCase()}`;
          if (!seenKeys.has(uniqueKey)) {
            seenKeys.add(uniqueKey);
            parsed.domElement = findClickableElementForGuestAndTime(parsed.guestName, parsed.promisedDate);
            parsedRows.push(parsed);
          }
        }
      }
    }

    for (const r of iframeRowsData) {
      if (isPastOrderTime(r.pickupIso)) continue;
      const uniqueKey = `${r.guestName.toLowerCase()}|${r.promisedDate.toLowerCase()}`;
      if (!seenKeys.has(uniqueKey)) {
        seenKeys.add(uniqueKey);
        parsedRows.push(r);
      }
    }

    if (window !== window.top) {
      root.style.display = 'none';
      if (parsedRows.length > 0) {
        window.top.postMessage({ source: 'CFA_KDS_IFRAME_ROWS', rows: parsedRows }, '*');
      }
      return parsedRows;
    }

    dashboardRowsData = parsedRows;
    upcomingCountEl.textContent = String(parsedRows.length);
    if (!isBulkCrawling) {
      syncAllBtn.textContent =
        parsedRows.length > 0
          ? `📥 Sync All (${parsedRows.length}) Orders + Food Details to KDS`
          : `📥 Sync All Orders + Food Details to KDS`;
    }

    if (parsedRows.length > 0 && !customerInput.value) {
      selectGuestOrder(parsedRows[0]);
    }

    checkAndAutoSyncOpenOrderSummary();
    rebuildDropdownOptions();
    return parsedRows;
  }

  // Whenever an Order Summary modal is open, extract Primary Contact, Cell #, Pickup Time, Delivery Address, Special Instructions, and Item Name + Quantity
  async function checkAndAutoSyncOpenOrderSummary() {
    const summaryData = parseOpenOrderSummary();
    if (!summaryData || summaryData.items.length === 0) {
      detectedBox.style.display = 'none';
      return null;
    }

    scrapedPageItems = summaryData.items;
    detectedBox.style.display = 'block';
    detectedCount.textContent = String(summaryData.items.length);
    detectedList.innerHTML = summaryData.items
      .map((i) => `<div>• <strong>${i.quantity}x</strong> ${i.name}</div>`)
      .join('');

    const activeGuest = summaryData.guestName || customerInput.value.trim();
    const activeTimeIso = parsePromisedDateToIso(summaryData.pickupTimeStr);

    // Prioritize matching the exact event row/KDS order by time AND guest/organization name
    const matchedRow = dashboardRowsData.find((r) => {
      const rowName = (r.guestName || '').toLowerCase();
      const guestLower = (activeGuest || '').toLowerCase();
      const nameMatches = !guestLower || rowName === guestLower || rowName.includes(guestLower) || guestLower.includes(rowName);
      if (activeTimeIso && r.pickupIso) {
        const timeMatches = Math.abs(new Date(r.pickupIso).getTime() - new Date(activeTimeIso).getTime()) < 3600000;
        return timeMatches && (nameMatches || !activeGuest);
      }
      return nameMatches;
    }) || dashboardRowsData.find(
      (r) => activeGuest && r.guestName.toLowerCase().includes(activeGuest.toLowerCase())
    );

    const matchedKds = kdsOrders.find((o) => {
      const kdsName = (o.customer_name || '').toLowerCase();
      const guestLower = (activeGuest || '').toLowerCase();
      const nameMatches = !guestLower || kdsName === guestLower || kdsName.includes(guestLower) || guestLower.includes(kdsName);
      if (activeTimeIso && o.pickup_time) {
        const timeMatches = Math.abs(new Date(o.pickup_time).getTime() - new Date(activeTimeIso).getTime()) < 3600000;
        return timeMatches && (nameMatches || !activeGuest);
      }
      return nameMatches;
    }) || kdsOrders.find(
      (o) => activeGuest && o.customer_name.toLowerCase().includes(activeGuest.toLowerCase())
    );

    const finalCustomerName = (matchedRow && matchedRow.guestName) || (matchedKds && matchedKds.customer_name) || activeGuest;
    const finalPaymentStatus = summaryData.paymentStatus || (matchedRow ? matchedRow.paymentStatus : 'Payment Received');

    // Never fall back to promisedInput.value if it belongs to a different guest!
    const finalTimeStr = summaryData.pickupTimeStr || (matchedRow ? matchedRow.promisedDate : '');
    const finalPickupIso =
      parsePromisedDateToIso(finalTimeStr) ||
      (matchedRow ? matchedRow.pickupIso : null) ||
      (matchedKds ? matchedKds.pickup_time : null);

    const finalOrderNum = matchedRow
      ? matchedRow.orderNumber
      : matchedKds
      ? matchedKds.order_number
      : buildOrderCode(finalCustomerName, finalTimeStr);
    const finalType =
      summaryData.orderType && summaryData.orderType !== 'Pickup'
        ? summaryData.orderType
        : matchedRow
        ? matchedRow.method
        : matchedKds
        ? matchedKds.order_type
        : typeSelect.value;

    if (finalCustomerName) customerInput.value = finalCustomerName;
    if (summaryData.contactPhone) phoneInput.value = summaryData.contactPhone;
    if (finalTimeStr) promisedInput.value = finalTimeStr;
    if (finalOrderNum) {
      orderNumInput.value = finalOrderNum;
      promisedBadge.textContent = finalOrderNum;
    }
    typeSelect.value = finalType;

    // Never auto-sync old orders whose pickup/delivery time is before the current time!
    if (isPastOrderTime(finalPickupIso) && !matchedKds) {
      return summaryData;
    }

    // If this order is in Error or Cancelled status and NOT already on the KDS, do not auto-sync it!
    if (isBadPaymentStatus(finalPaymentStatus) && !matchedKds) {
      return summaryData;
    }

    const sig = `${finalCustomerName}|${finalOrderNum}|${finalPaymentStatus}|${summaryData.items.map((i) => `${i.quantity}:${i.name}`).join(',')}`;
    if (!isBulkCrawling && finalCustomerName && sig !== lastAutoSyncedSignature) {
      lastAutoSyncedSignature = sig;

      const res = await callKdsApi({
        type: 'KDS_SYNC_ORDER',
        payload: {
          order_number: finalOrderNum,
          customer_name: finalCustomerName,
          customer_phone: summaryData.contactPhone || '',
          organization: summaryData.deliveryAddress || '',
          pickup_time: finalPickupIso,
          order_type: finalType,
          payment_status: finalPaymentStatus,
          special_notes: summaryData.specialNotes || '',
          items: summaryData.items,
          flash_kitchen: false,
          sync_mode: 'sync',
          submitted_by: 'CFA Home Order Summary Auto-Sync'
        }
      });

      if (res && res.ok) {
        if (isBadPaymentStatus(finalPaymentStatus)) {
          showToast(
            `⚠️ Flagged ${activeGuest} as ${finalPaymentStatus.toUpperCase()} on Kitchen KDS!`,
            'error'
          );
        } else {
          showToast(
            `✓ Synced ${activeGuest} (${summaryData.items.length} food items) to Kitchen KDS!`,
            'success'
          );
        }
        await refreshKdsOrders();
      }
    }

    return summaryData;
  }

  window.addEventListener('message', (e) => {
    if (e.data && e.data.source === 'CFA_KDS_IFRAME_ROWS' && Array.isArray(e.data.rows)) {
      iframeRowsData = e.data.rows;
      scanCfaDashboardAndTabs();
    }
  });

  function rebuildDropdownOptions() {
    const currentVal = existingSelect.value;
    existingSelect.innerHTML = `<option value="__new__">➕ Sync Selected CFA Home Guest Order</option>`;

    if (dashboardRowsData.length > 0) {
      const dashGroup = document.createElement('optgroup');
      dashGroup.label = `📋 On CFA Home Dashboard (${dashboardRowsData.length})`;
      dashboardRowsData.forEach((r, idx) => {
        const opt = document.createElement('option');
        opt.value = `dash_${idx}`;
        const payTag = isBadPaymentStatus(r.paymentStatus) ? ` [⚠️ ${r.paymentStatus.toUpperCase()}]` : '';
        opt.textContent = `${r.guestName}${payTag} — ${r.promisedDate} (${r.method})`;
        dashGroup.appendChild(opt);
      });
      existingSelect.appendChild(dashGroup);
    }

    if (kdsOrders.length > 0) {
      const kdsGroup = document.createElement('optgroup');
      kdsGroup.label = `🍳 Active on Kitchen Touchscreen (${kdsOrders.length})`;
      kdsOrders.forEach((o) => {
        const opt = document.createElement('option');
        opt.value = o.id;
        opt.textContent = `${o.order_number} — ${o.customer_name} (${o.order_type})`;
        kdsGroup.appendChild(opt);
      });
      existingSelect.appendChild(kdsGroup);
    }

    if (currentVal && Array.from(existingSelect.options).some((o) => o.value === currentVal)) {
      existingSelect.value = currentVal;
    }
  }

  existingSelect.addEventListener('change', () => {
    const val = existingSelect.value;
    if (val.startsWith('dash_')) {
      const idx = Number(val.replace('dash_', ''));
      if (dashboardRowsData[idx]) {
        selectGuestOrder(dashboardRowsData[idx]);
      }
      return;
    }
    const found = kdsOrders.find((o) => o.id === val);
    if (found) {
      customerInput.value = found.customer_name || '';
      phoneInput.value = found.customer_phone || '';
      orderNumInput.value = found.order_number || '';
      promisedBadge.textContent = found.order_number || '';
      promisedInput.value = new Date(found.pickup_time).toLocaleString();
      typeSelect.value = found.order_type || 'Pickup';
    }
  });

  async function refreshKdsOrders() {
    const res = await callKdsApi({ type: 'KDS_GET_ORDERS' });
    if (!res || !res.ok) {
      connText.textContent = '⚠️ Kitchen Server Offline (Run start.bat)';
      statusDot.classList.add('offline');
      return;
    }
    connText.textContent = `✓ Kitchen Live (${res.orders.length} orders on KDS)`;
    statusDot.classList.remove('offline');
    kdsOrders = res.orders || [];
    rebuildDropdownOptions();
  }

  // Wait for the Order Summary modal to actually display the target guest or matching time
  function waitForGuestSummary(guestName, expectedTimeStr = '', timeoutMs = 2800) {
    return new Promise((resolve) => {
      const start = Date.now();
      const targetLower = (guestName || '').toLowerCase().trim();
      const targetWords = targetLower.split(/\s+/).filter((w) => w.length >= 3);

      // Extract time component like "9:15" or "1:00" or "6:15" from expectedTimeStr if present
      let expectedTimeClean = '';
      if (expectedTimeStr) {
        const tm = expectedTimeStr.match(/\b\d{1,2}:\d{2}\s*[ap]m\b/i);
        if (tm) expectedTimeClean = tm[0].toLowerCase().replace(/\s+/g, '');
      }

      const timer = setInterval(() => {
        const parsed = parseOpenOrderSummary();
        if (
          parsed &&
          parsed.items.length > 0
        ) {
          // If expected time is provided, verify it matches
          let timeMatches = false;
          if (expectedTimeClean && parsed.pickupTimeStr) {
            const parsedTm = parsed.pickupTimeStr.match(/\b\d{1,2}:\d{2}\s*[ap]m\b/i);
            if (parsedTm && parsedTm[0].toLowerCase().replace(/\s+/g, '') === expectedTimeClean) {
              timeMatches = true;
            }
          }

          const parsedGuestLower = (parsed.guestName || '').toLowerCase();
          const nameMatches =
            !targetLower ||
            !parsedGuestLower ||
            parsedGuestLower.includes(targetLower) ||
            targetLower.includes(parsedGuestLower) ||
            targetWords.some((w) => parsedGuestLower.includes(w));

          if (timeMatches || nameMatches) {
            clearInterval(timer);
            resolve(parsed);
            return;
          }
        }
        if (Date.now() - start >= timeoutMs) {
          clearInterval(timer);
          resolve(parsed && parsed.items.length > 0 ? parsed : null);
        }
      }, 100);
    });
  }

  // Sync ALL Upcoming Orders + Automatically open each Order Summary to pull Food & Quantities!
  async function runBulkDashboardSync({ isAuto = false } = {}) {
    if (isBulkCrawling) return;

    const rows = scanCfaDashboardAndTabs();
    if (rows.length === 0) {
      const openSummary = await checkAndAutoSyncOpenOrderSummary();
      if (openSummary) return;
      if (!isAuto) {
        showToast('No Upcoming order rows found on page.', 'error');
      }
      return;
    }

    isBulkCrawling = true;
    syncAllBtn.disabled = true;

    let syncedCount = 0;
    let skippedBadCount = 0;
    let flaggedBadCount = 0;
    let itemsCapturedCount = 0;

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (isPastOrderTime(row.pickupIso)) {
        continue;
      }

      const alreadyOnKds = kdsOrders.find(
        (o) =>
          (row.orderNumber && o.order_number.toLowerCase() === row.orderNumber.toLowerCase()) ||
          (o.customer_name.toLowerCase() === (row.guestName || '').toLowerCase() &&
           row.pickupIso && o.pickup_time &&
           Math.abs(new Date(o.pickup_time).getTime() - new Date(row.pickupIso).getTime()) < 3600000)
      );

      // If row's Payment Status is Error or Cancelled:
      // - Skip it completely if it is NOT already on the KDS
      // - Flag it on the KDS if it WAS already synced earlier!
      if (isBadPaymentStatus(row.paymentStatus)) {
        if (!alreadyOnKds) {
          skippedBadCount++;
          continue;
        }
        syncAllBtn.textContent = `⚠️ Flagging ${row.paymentStatus}: ${row.guestName}...`;
        const flagRes = await callKdsApi({
          type: 'KDS_SYNC_ORDER',
          payload: {
            order_number: alreadyOnKds.order_number || row.orderNumber,
            customer_name: row.guestName,
            pickup_time: parsePromisedDateToIso(row.promisedDate) || alreadyOnKds.pickup_time,
            order_type: row.method || alreadyOnKds.order_type,
            payment_status: row.paymentStatus,
            flash_kitchen: true,
            sync_mode: 'sync',
            submitted_by: isAuto ? 'CFA Home Game-Day Auto-Sync' : 'CFA Home Dashboard Deep-Sync'
          }
        });
        if (flagRes && flagRes.ok) flaggedBadCount++;
        continue;
      }

      syncAllBtn.textContent = `⏳ Reading Food (${i + 1}/${rows.length}): ${row.guestName}...`;

      // 1. Close any previously open modal so backdrop doesn't block clicking this row
      closeOpenCfaModal();
      await new Promise((r) => setTimeout(r, 180));

      // 2. Click the target row element with tablet touch + pointer events
      const clickTarget = findClickableElementForRow(row);
      if (clickTarget) {
        triggerElementTap(clickTarget);
      }

      // 3. Wait for summary modal (up to 2800ms for tablet latency and Wi-Fi response)
      const summary = await waitForGuestSummary(row.guestName, row.promisedDate, 2800);
      const effectivePayStatus = (summary && summary.paymentStatus) || row.paymentStatus || 'Payment Received';

      // Double-check if modal revealed Error or Cancelled status
      if (isBadPaymentStatus(effectivePayStatus) && !alreadyOnKds) {
        skippedBadCount++;
        closeOpenCfaModal();
        await new Promise((r) => setTimeout(r, 120));
        continue;
      }

      const orderItems = summary && summary.items ? summary.items : [];
      if (orderItems.length > 0) itemsCapturedCount += orderItems.length;

      const finalTimeStr = (summary && summary.pickupTimeStr) || row.promisedDate;
      const finalPickupIso = parsePromisedDateToIso(finalTimeStr) || row.pickupIso;
      if (isPastOrderTime(finalPickupIso) && !alreadyOnKds) {
        closeOpenCfaModal();
        await new Promise((r) => setTimeout(r, 120));
        continue;
      }
      const finalType = (summary && summary.orderType) || row.method;

      const res = await callKdsApi({
        type: 'KDS_SYNC_ORDER',
        payload: {
          order_number: row.orderNumber,
          customer_name: (summary && summary.guestName) || row.guestName,
          customer_phone: (summary && summary.contactPhone) || '',
          organization: (summary && summary.deliveryAddress) || '',
          pickup_time: finalPickupIso,
          order_type: finalType,
          payment_status: effectivePayStatus,
          special_notes: (summary && summary.specialNotes) || '',
          items: orderItems,
          flash_kitchen: false,
          sync_mode: 'sync',
          submitted_by: isAuto ? 'CFA Home Game-Day Auto-Sync' : 'CFA Home Dashboard Deep-Sync'
        }
      });

      if (res && res.ok) {
        if (isBadPaymentStatus(effectivePayStatus)) {
          flaggedBadCount++;
        } else {
          syncedCount++;
        }
      }

      // Close modal before proceeding to next row
      closeOpenCfaModal();
      await new Promise((r) => setTimeout(r, 180));
    }

    isBulkCrawling = false;
    syncAllBtn.disabled = false;
    syncAllBtn.textContent = `📥 Sync All (${rows.length}) Orders + Food Details to KDS`;

    const timeStamp = new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    localStorage.setItem('cfa_kds_last_autosync_time', timeStamp);

    const extraNotes = [];
    if (skippedBadCount > 0) extraNotes.push(`Skipped ${skippedBadCount} Error/Cancelled`);
    if (flaggedBadCount > 0) extraNotes.push(`Alerted Kitchen on ${flaggedBadCount} Error/Cancelled`);
    const suffix = extraNotes.length > 0 ? ` (${extraNotes.join(' • ')})` : '';

    showToast(
      `✓ ${isAuto ? 'Auto-Synced' : 'Synced'} ${syncedCount} orders (${itemsCapturedCount} food items)${suffix} at ${timeStamp}!`,
      'success'
    );
    await refreshKdsOrders();
  }

  syncAllBtn.addEventListener('click', () => {
    runBulkDashboardSync({ isAuto: false });
  });

  // --- GAME DAY AUTO-REFRESH & UPLOAD ENGINE (Default option: Every 15 Minutes) ---
  const autoSyncSelect = document.getElementById('cfa-kds-autosync-interval');
  const autoSyncStatus = document.getElementById('cfa-kds-autosync-status');

  // Default to 15 minutes if never configured before, or restore saved setting
  const savedAutoSyncMins = localStorage.getItem('cfa_kds_autosync_mins');
  let autoSyncMinutes = savedAutoSyncMins !== null ? Number(savedAutoSyncMins) : 15;
  if (![0, 5, 10, 15].includes(autoSyncMinutes)) autoSyncMinutes = 15;
  autoSyncSelect.value = String(autoSyncMinutes);

  let autoSyncRemainingSec = autoSyncMinutes * 60;

  function formatCountdown(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  function updateAutoSyncStatusBadge() {
    if (autoSyncMinutes <= 0) {
      autoSyncStatus.textContent = 'Paused';
      autoSyncStatus.style.color = '#64748B';
      return;
    }
    const lastTime = localStorage.getItem('cfa_kds_last_autosync_time');
    const prefix = lastTime ? `✓ ${lastTime} • ` : '';
    autoSyncStatus.textContent = `${prefix}Next: ${formatCountdown(autoSyncRemainingSec)}`;
    autoSyncStatus.style.color = '#1E40AF';
  }

  autoSyncSelect.addEventListener('change', () => {
    autoSyncMinutes = Number(autoSyncSelect.value) || 0;
    localStorage.setItem('cfa_kds_autosync_mins', String(autoSyncMinutes));
    autoSyncRemainingSec = autoSyncMinutes * 60;
    updateAutoSyncStatusBadge();
    if (autoSyncMinutes > 0) {
      showToast(`⏱️ Game Day Auto-Refresh set to every ${autoSyncMinutes} minutes!`, 'success');
    } else {
      showToast('⏸️ Auto-Refresh turned off.', 'success');
    }
  });

  if (window === window.top) {
    updateAutoSyncStatusBadge();

    // Check if the page just reloaded from an Auto-Refresh cycle
    if (sessionStorage.getItem('cfa_kds_pending_autosync') === '1') {
      sessionStorage.removeItem('cfa_kds_pending_autosync');
      autoSyncStatus.textContent = '⏳ Waiting for CMT rows...';

      let attempts = 0;
      const waitPoll = setInterval(async () => {
        attempts++;
        const rows = scanCfaDashboardAndTabs();
        if (rows.length > 0 || attempts >= 10) {
          clearInterval(waitPoll);
          if (rows.length > 0) {
            autoSyncStatus.textContent = `⏳ Auto-Syncing (${rows.length})...`;
            // Brief 1s settle time so all table rows finish rendering
            await new Promise((r) => setTimeout(r, 1000));
            await runBulkDashboardSync({ isAuto: true });
          }
          autoSyncRemainingSec = autoSyncMinutes * 60;
          updateAutoSyncStatusBadge();
        }
      }, 1500);
    }

    // 1-second tick for the Game Day Auto-Refresh countdown
    setInterval(() => {
      if (autoSyncMinutes <= 0 || isBulkCrawling) return;

      autoSyncRemainingSec--;
      if (autoSyncRemainingSec <= 0) {
        // Postpone 30s if someone is actively typing in the extension widget
        const activeEl = document.activeElement;
        if (activeEl && root.contains(activeEl) && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
          autoSyncRemainingSec = 30;
          updateAutoSyncStatusBadge();
          return;
        }

        // Trigger page reload and mark pending auto-sync in sessionStorage
        autoSyncStatus.textContent = '🔄 Refreshing CMT...';
        sessionStorage.setItem('cfa_kds_pending_autosync', '1');
        window.location.reload();
        return;
      }

      updateAutoSyncStatusBadge();
    }, 1000);
  }

  scanBtn.addEventListener('click', async () => {
    const rows = scanCfaDashboardAndTabs();
    const summary = await checkAndAutoSyncOpenOrderSummary();
    if (summary && summary.items.length > 0) {
      showToast(`✓ Synced ${summary.guestName || 'Guest'}: ${summary.items.length} food items to KDS!`);
    } else {
      showToast(`✓ Detected ${rows.length} Upcoming guest orders on Dashboard`);
    }
  });

  async function dispatchToKitchen({ items = [], customNote = '', flashKitchen = true }) {
    const customerName = customerInput.value.trim() || 'CFA Catering Guest';
    const customerPhone = phoneInput.value.trim();
    const promisedStr = promisedInput.value.trim();
    const orderNumber = orderNumInput.value.trim() || buildOrderCode(customerName, promisedStr);
    const orderType = typeSelect.value;

    const selectedVal = existingSelect.value;
    const matchedKdsOrder =
      kdsOrders.find((o) => o.id === selectedVal) ||
      kdsOrders.find(
        (o) =>
          o.order_number.toLowerCase() === orderNumber.toLowerCase() ||
          o.customer_name.toLowerCase() === customerName.toLowerCase()
      );

    if (matchedKdsOrder && items.length + customNote.length > 0) {
      const res = await callKdsApi({
        type: 'KDS_QUICK_ADD',
        orderId: matchedKdsOrder.id,
        payload: {
          items,
          urgency: flashKitchen ? 'urgent' : 'normal',
          custom_note: customNote,
          submitted_by: 'CFA Home Dashboard'
        }
      });
      if (res && res.ok) {
        showToast(`🚨 Kitchen Flashing Red for ${customerName} (${matchedKdsOrder.order_number})!`, 'success');
        customItemInput.value = '';
        noteInput.value = '';
        await refreshKdsOrders();
      } else {
        showToast(res?.error || 'Failed to reach Kitchen KDS', 'error');
      }
      return;
    }

    const combinedItems = items.length > 0 ? items : scrapedPageItems;
    const res = await callKdsApi({
      type: 'KDS_SYNC_ORDER',
      payload: {
        order_number: orderNumber,
        customer_name: customerName,
        customer_phone: customerPhone,
        pickup_time: parsePromisedDateToIso(promisedStr),
        order_type: orderType,
        items: combinedItems,
        custom_note: customNote,
        flash_kitchen: flashKitchen,
        sync_mode: 'quick_add',
        submitted_by: 'CFA Home Dashboard'
      }
    });

    if (res && res.ok) {
      showToast(`🚨 Synced ${customerName} & Flashing Red on Kitchen Touchscreen!`, 'success');
      orderNumInput.value = res.data.order.order_number;
      customItemInput.value = '';
      noteInput.value = '';
      await refreshKdsOrders();
    } else {
      showToast(res?.error || 'Failed to sync to Kitchen KDS', 'error');
    }
  }

  document.querySelectorAll('.cfa-kds-preset-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const item = {
        name: btn.getAttribute('data-name'),
        quantity: Number(btn.getAttribute('data-qty')) || 1,
        category: btn.getAttribute('data-cat') || 'Sauces',
        unit: btn.getAttribute('data-unit') || 'Packets'
      };
      dispatchToKitchen({
        items: [item],
        customNote: noteInput.value.trim(),
        flashKitchen: true
      });
    });
  });

  sendBtn.addEventListener('click', () => {
    const customName = customItemInput.value.trim();
    const customQty = Number(customQtyInput.value) || 1;
    const note = noteInput.value.trim();

    const items = [];
    if (customName) {
      items.push({
        name: customName,
        quantity: customQty,
        category: 'Added Item',
        unit: 'count'
      });
    }

    dispatchToKitchen({
      items,
      customNote: note,
      flashKitchen: true
    });
  });

  const observer = new MutationObserver(() => {
    if (isBulkCrawling) return;
    clearTimeout(window._cfaScanTimer);
    window._cfaScanTimer = setTimeout(scanCfaDashboardAndTabs, 450);
  });
  observer.observe(document.body, { childList: true, subtree: true });

  refreshKdsOrders();
  setTimeout(scanCfaDashboardAndTabs, 500);
  setInterval(refreshKdsOrders, 10000);
})();
